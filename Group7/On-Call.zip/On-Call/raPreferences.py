raPreferences = {}
