'''
	Author: Kiana Hosaka
	Date Last Modified: February 19, 2020
	Description: Test file for Weekend Schedules
'''

# Weekend: Friday, Saturday Day, Saturday Night, Sunday Day
'''
primary_1 = ["X", "Andy", "Donya", "Natalie"]
secondary_1 = ["X", "Ryan", "Alison", "Celine"]
primary_2 = ["Grace", "Andy", "Donya", "Natalie"]
secondary_2 = ["Tiffanie", "Ryan", "Alison", "Celine"]
primary_3 = ["Grace", "Andy", "Donya", "Natalie"]
secondary_3 = ["Tiffanie", "Ryan", "Alison", "Celine"]
primary_4 = ["Grace", "Andy", "Donya", "Natalie"]
secondary_4 = ["Tiffanie", "Ryan", "Alison", "Celine"]
primary_5 = ["Grace", "Andy", "Donya", "Natalie"]
secondary_5 = ["Tiffanie", "Ryan", "Alison", "Celine"]
primary_6 = ["Grace", "Andy", "Donya", "Natalie"]
secondary_6 = ["Tiffanie", "Ryan", "Alison", "Celine"]
primary_7 = ["Grace", "Andy", "Donya", "Natalie"]
secondary_7 = ["Tiffanie", "Ryan", "Alison", "Celine"]
primary_8 = ["Grace", "Andy", "Donya", "Natalie"]
secondary_8 = ["Tiffanie", "Ryan", "Alison", "Celine"]
primary_9 = ["Grace", "Andy", "Donya", "Natalie"]
secondary_9 = ["Tiffanie", "Ryan", "Alison", "Celine"]
primary_10 = ["Grace", "Andy", "Donya", "Natalie"]
secondary_10 = ["Tiffanie", "Ryan", "Alison", "Celine"]
'''
primary_1 = ["P1 Friday", "P1 Saturday Day", "P1 Saturday Night", "X"]
secondary_1 = ["S1 Friday", "S1 Saturday Day", "S1 Saturday Night", "X"]
primary_2 = ["P2 Friday", "P2 Saturday Day", "P2 Saturday Night", "P2 Sunday Day"]
secondary_2 = ["S2 Friday", "S2 Saturday Day", "S2 Saturday Night", "S2 Sunday Day"]
primary_3 = ["P3 Friday", "P3 Saturday Day", "P3 Saturday Night", "P3 Sunday Day"]
secondary_3 = ["S3 Friday", "S3 Saturday Day", "S3 Saturday Night", "S3 Sunday Day"]
primary_4 = ["P4 Friday", "P4 Saturday Day", "P4 Saturday Night", "P4 Sunday Day"]
secondary_4 = ["S4 Friday", "S4 Saturday Day", "S4 Saturday Night", "S4 Sunday Day"]
primary_5 = ["P5 Friday", "P5 Saturday Day", "P5 Saturday Night", "P5 Sunday Day"]
secondary_5 = ["S5 Friday", "S5 Saturday Day", "S5 Saturday Night", "S5 Sunday Day"]
primary_6 = ["P6 Friday", "P6 Saturday Day", "P6 Saturday Night", "P6 Sunday Day"]
secondary_6 = ["S6 Friday", "S6 Saturday Day", "S6 Saturday Night", "S6 Sunday Day"]
primary_7 = ["P7 Friday", "P7 Saturday Day", "P7 Saturday Night", "P7 Sunday Day"]
secondary_7 = ["S7 Friday", "S7 Saturday Day", "S7 Saturday Night", "S7 Sunday Day"]
primary_8 = ["P8 Friday", "P8 Saturday Day", "P8 Saturday Night", "P8 Sunday Day"]
secondary_8 = ["S8 Friday", "S8 Saturday Day", "S8 Saturday Night", "S8 Sunday Day"]
primary_9 = ["P9 Friday", "P9 Saturday Day", "P9 Saturday Night", "P9 Sunday Day"]
secondary_9 = ["S9 Friday", "S9 Saturday Day", "S9 Saturday Night", "S9 Sunday Day"]
primary_10 = ["P10 Friday", "P10 Saturday Day", "P10 Saturday Night", "P10 Sunday Day"]
secondary_10 = ["S10 Friday", "S10 Saturday Day", "S10 Saturday Night", "S10 Sunday Day"]

schedule = [[primary_1, secondary_1], [primary_2, secondary_2], [primary_3, secondary_3], \
		[primary_4, secondary_4], [primary_5, secondary_5], [primary_6, secondary_6], \
		[primary_7, secondary_7], [primary_8, secondary_8], [primary_9, secondary_9], \
		[primary_10, secondary_10]]
