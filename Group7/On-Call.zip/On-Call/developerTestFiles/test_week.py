'''
	Author: Kiana Hosaka
	Date Last Modified: February 19, 2020
	Description: Test file for Weekday Schedules
'''

# Weekday: Sunday Night, Monday, Tuesday, Wedesday, Thursday
'''
primary_1 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_1 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
primary_2 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_2 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
primary_3 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_3 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
primary_4 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_4 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
primary_5 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_5 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
primary_6 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_6 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
primary_7 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_7 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
primary_8 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_8 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
primary_9 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_9 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
primary_10 = ["Ally", "Maddie", "Alia", "Josiah", "Fran"]
secondary_10 = ["Maddie", "Alia", "Ally", "Sam", "Jacob"]
'''

primary_1 = ["P1 Sun Night", "P1 Monday", "P1 Tuesday", "P1 Wednesday", "P1 Thursday"]
secondary_1 = ["S1 Sun Night", "S1 Monday", "S1 Tuesday", "S1 Wednesday", "S1 Thursday"]
primary_2 = ["P2 Sun Night", "P2 Monday", "P2 Tuesday", "P2 Wednesday", "P2 Thursday"]
secondary_2 = ["S2 Sun Night", "S2 Monday", "S2 Tuesday", "S2 Wednesday", "S2 Thursday"]
primary_3 = ["P3 Sun Night", "P3 Monday", "P3 Tuesday", "P3 Wednesday", "P3 Thursday"]
secondary_3 = ["S3 Sun Night", "S3 Monday", "S3 Tuesday", "S3 Wednesday", "S3 Thursday"]
primary_4 = ["P4 Sun Night", "P4 Monday", "P4 Tuesday", "P4 Wednesday", "P4 Thursday"]
secondary_4 = ["S4 Sun Night", "S4 Monday", "S4 Tuesday", "S4 Wednesday", "S4 Thursday"]
primary_5 = ["P5 Sun Night", "P5 Monday", "P5 Tuesday", "P5 Wednesday", "P5 Thursday"]
secondary_5 = ["S5 Sun Night", "S5 Monday", "S5 Tuesday", "S5 Wednesday", "S5 Thursday"]
primary_6 = ["P6 Sun Night", "P6 Monday", "P6 Tuesday", "P6 Wednesday", "P6 Thursday"]
secondary_6 = ["S6 Sun Night", "S6 Monday", "S6 Tuesday", "S6 Wednesday", "S6 Thursday"]
primary_7 = ["P7 Sun Night", "P7 Monday", "P7 Tuesday", "P7 Wednesday", "P7 Thursday"]
secondary_7 = ["S7 Sun Night", "S7 Monday", "S7 Tuesday", "S7 Wednesday", "S7 Thursday"]
primary_8 = ["P8 Sun Night", "P8 Monday", "P8 Tuesday", "P8 Wednesday", "P8 Thursday"]
secondary_8 = ["S8 Sun Night", "S8 Monday", "S8 Tuesday", "S8 Wednesday", "S8 Thursday"]
primary_9 = ["P9 Sun Night", "P9 Monday", "P9 Tuesday", "P9 Wednesday", "P9 Thursday"]
secondary_9 = ["S9 Sun Night", "S9 Monday", "S9 Tuesday", "S9 Wednesday", "S9 Thursday"]
primary_10 = ["P10 Sun Night", "P10 Monday", "P10 Tuesday", "P10 Wednesday", "P10 Thursday"]
secondary_10 = ["S10 Sun Night", "S10 Monday", "S10 Tuesday", "S10 Wednesday", "S10 Thursday"]

schedule = [[primary_1, secondary_1], [primary_2, secondary_2], [primary_3, secondary_3], \
		[primary_4, secondary_4], [primary_5, secondary_5], [primary_6, secondary_6], \
		[primary_7, secondary_7], [primary_8, secondary_8], [primary_9, secondary_9], \
		[primary_10, secondary_10]]
